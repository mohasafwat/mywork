/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + 1 + "/" + d.getDate() + "/" + d.getFullYear();



const baseUrl = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = '&appid=c04568c44011a881f9416b16fab51b84&units=imperial';


document.getElementById('generate').addEventListener('click', perdormAction);
let fav = document.getElementById('feelings').value;
let temp = document.getElementById('temp').value;
function perdormAction(e) {
  let newZip = document.getElementById('zip').value;
  let fav = document.getElementById('feelings').value;

  getAnimal(baseUrl + newZip + apiKey)
    .then((data) => {
      posttData(data)
        .then((someData) => {

          postData('/add', { newDate, feeling: fav, temp: data.main.temp })
            .then((data) => {
              retrieveData('/all');


            })
        })

    })
  
}
const posttData = async (data) => {
  try {
    //const newData = await response.json();
    const someData = { newDate, feeling: fav, temp: data.main.temp };
    console.log(someData);
    return someData;
  } catch (error) {
    console.log('error', error);

  }
}

const postData = async (url = '', data = {}) => {
  const response = await fetch(url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'content-Type': 'application/json',
    },
    body: JSON.stringify(data),

  });
  try {
    const newData = await response.json();
    console.log(newData);
    return newData;
  } catch (error) {
    console.log('error', error);

  }
}

const getAnimal = async (url) => {
  const res = await fetch(url);

  try {
    const data = await res.json();
    console.log(data);
    return data;

  } catch (error) {
    console.log('error', error);

  }

}

const retrieveData = async (url) => {
  const request = await fetch('/all');
  try {
    // Transform into JSON
    const allData = await request.json()
    console.log(allData)
    // Write updated data to DOM elements
    document.getElementById('temp').innerHTML = Math.round(allData.temp) + 'degrees';
    document.getElementById('content').innerHTML = allData.feeling;
    document.getElementById("date").innerHTML = allData.newDate;
  }
  catch (error) {
    console.log("error", error);
    // appropriately handle the error
  }
}