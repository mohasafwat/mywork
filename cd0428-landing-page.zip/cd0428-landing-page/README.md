# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

project description:

This project aims to give you real-world scenarios of manipulating the DOM.
This project requires you to build a multi-section landing page, with a dynamically updating navigational menu based on the amount of content that is added to the page.
to prepare you for appending dynamically added data to the DOM.
 This project barely touches the surface of what is possible, but it does use some incredibly common events, methods, and logic.

usage:

dynamically building the navigation is a great precursor to understanding the virtual DOM which you will experience when you begin working with JavaScript frameworks.
Additionally, when a user clicks on a navigation item, the item should scroll you to the appropriate section rather than giving you the default jump.
programmatically builds navigation.
scrolls to anchors from navigation.
 highlights section in viewport upon scrolling.

dependencies: none.

