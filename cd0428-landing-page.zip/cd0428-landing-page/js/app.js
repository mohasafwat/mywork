/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/


/**
 * Define Global Variables
 * 
*/
//get the container of navigation bar items , store it in contain variable.
const contain = document.getElementById("navbar__list");
//get all the sections of my landing page , store it in sections variable.
const sections = document.getElementsByTagName("section");

// build the nav

//create loop to make nav bar links based on number of sections that my landing page contain.

for (let index = 1; index <= sections.length; index++) {
    //create "li" element
    const navitem = document.createElement("li");
    // create link element 
    const navLink = document.createElement("a");

    navLink.className = "menu__link";
    navLink.innerHTML = "section" + index;
    contain.appendChild(navitem);
    navitem.appendChild(navLink);
    navLink.addEventListener('click', myfun);
    // function implement Scroll to section on link click
    function myfun() {
        document.getElementById("section" + index).scrollIntoView({ behavior: 'smooth' });
    }

}
//get all the links of my navigation bar , store it in items variable.
const items = document.getElementsByClassName("menu__link");


//add event to document to Make sections active when scroll
document.addEventListener("scroll", makeActive);
//function implement when scrolling 

function makeActive() {
    let i = 0;
    for (const section of sections) {
        const box = section.getBoundingClientRect();
        //Find a value that works best, but 150 seems to be a good start.
        if (box.top <= 150 && box.bottom >= 150) {
            //apply active state on current section and corresponding Nav link
            section.classList.add("your-active-class");
            items[i].classList.add("active");
        } else {
            //Remove active state from other section and corresponding Nav link
            section.classList.remove("your-active-class");
            items[i].classList.remove("active");
        }
        i++;
    }
}







